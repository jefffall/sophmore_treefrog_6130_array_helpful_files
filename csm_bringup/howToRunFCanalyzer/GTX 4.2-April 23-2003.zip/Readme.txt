Finisar Corporation	   GTX-A v 4.2 Readme        Build 049 February 19, 2003
==================================================================================

Index
=====
I.   New Features
II.  System Requirements
III. Installation
IV.  Compatibility and Interoperability
V.   How to Contact Us


I. New Features
---------------

GTX-A 4.2 is mainly an upgrade for the GTX-SANMetrics software which now
supports:
- All versions through iSCSI Draft 20, with many new experts tailored to 
  Draft 20 behavior.
- iSCSI Expert PDU Trace generation for saved iSCSI traces.
- Adds an additional 200 Fibre Channel and iSCSI Expert symptom checks.
- Many enhancements to both iSCSI and Fibre Channel handling.
- Much needed performance improvements while processing traces.
- Additional information provided per expert
- Support for native E_Port Class F traffic.
- Fixes for various TCP retransmission/repacketization boundary cases.
- Aging thresholds for cleared and end-of-trace events that are hard to detect.

Besides the new GTX-SANMetrics software, following are the new features of
GTX-A 4.2 Trace View:

- Now supports iSCSI Draft 20 (GTX-A 4.0 supported iSCSI Draft 9, 
  GTX-A 4.1 supported Draft 13).
- Added support for FCIP tunneling traffic on TCP port 0xc99.
- Supports GTX-SANMetrics generated iSCSI Expert PDU traces - allows for
  viewing/filtering only iSCSI PDU (thus removing the TCP layer).  Includes
  performance and behavioral experts in record (Exchange Aging, Pending I/O 
  Counts, etc).


II. System Requirements
-----------------------
	- Processor: Pentium III 500MHz or greater (1 GHz processor recommended)
	- Memory   : 512MB RAM (1GB RAM recommended)
	- Video    : 256 colors, 1024 X 768 or greater resolution.
	- Storage  : 30 GB HDD or larger 
	- Minimum free space for installation: 260MB 
	- Operating System (s) - Windows NT4.0 SP6 , Win2K Server,
	  Win2K Professional
	- Other: Internet Explorer 5.0 or greater
	
	
III. Installation
-----------------
	1. If you have older GTX-A or IBT software, use the add \ remove windows 
	utility to uninstall the older GTX-A software and the GTX-SANMetrics
	software.
	
	Warning: When uninstalling GTX-A V3.0 or earlier, you must also 
        uninstall the GTX-SANMetrics software.

	2. Install GTX-A v4.2 by clicking on setup.exe, following the 
	installation script and rebooting the PC.The GTX-A software suite
	along with the necessary hardware driver and Finisar bit files will
	be installed.

	3. GTX-A hardware cards should automatically be recognized upon reboot.

	Default Installation Directory	: C:\Program Files\Finisar\GTX
	Driver and Bitfile locations	: C:\Winnt\System32\Drivers


	** If Analyzer cards are not recognized by TraceController after 
	installation and subsequent reboot, please read the Installation 
	Troubleshooting	document provided with this software or contact
	Technical Support for help.	


IV. Compatibility and Interoperability Issues
---------------------------------------------
****************************************************************************
Compatibility and interoperability with the Finisar GT series of products
Was not tested and therefore not supported with this software.
****************************************************************************

1. Software
	  
	1. Older GTX-A and GTX-SANMetrics software must be uninstalled
	   prior to installing GTX-A 4.2 software.  

	2. The following software can co-exist with each other on the same 
	   System: GTX-G, GTX-J, GTX-B, Surveyor 4.2, and  SANQoS.
	

2. Hardware Compatibility
	**Can co-exist together with other Finisar hardware components

	1. GTX-A of each protocol type, FC, IBT, GigE

	2. THGm (10/100/1000 Ethernet Analyzer)
	
	3. GTX-G (Generator), GTX-B (Bert), GTX-J (Jammer)

	4. GTX-A Rose card supported

	
3. Platform Tested

	1. Dolch with Win NT or Win2K Professional & Server

	2. 16 slot rack mount system with Win 2K server only

	3. Minimax Notebook System with Win 2K Professional only
	


V. How to Contact Us
--------------------

Finisar Corporation
Instruments Division
1389 Moffett Park Drive
Sunnyvale, CA 94089-1133

Main Phone # : 408 400-1000
Fax #        : 408 744-1778
Tech Support#: 408 400-1100
Web site     : www.finisar.com
Email	     : techsupport@finisar.com


